package com.manisha.dao;
import com.manisha.database.ConnectionFactory;
import com.manisha.pojo.Employee;


	import java.sql.Connection;
	import java.sql.PreparedStatement;
	import java.sql.ResultSet;
	import java.sql.SQLException;
	import java.util.Calendar;

	public class EmployeeDAO {
		
		public int insert(Employee emp) throws SQLException {
			String query="insert into Employee values(?,?,?,?,?,?,?,?)";
			Connection conn =ConnectionFactory.getConnection();
			PreparedStatement pStatement= conn.prepareStatement(query);
			pStatement.setInt(1, emp.getEmpNo());
			pStatement.setString(2, emp.getEname());
			pStatement.setString(3, emp.getJob());
			pStatement.setInt(4, emp.getMgr());
			pStatement.setDate(5, emp.getHiredate());
			pStatement.setDouble(6,  emp.getSal());
			pStatement.setDouble(7, emp.getComm());
			pStatement.setInt(8, emp.getDeptNo());
			int output=pStatement.executeUpdate();
			return output;
			
		}
		
		public Employee read(int empNo) throws SQLException {
			String query="select * from Employee where empNo= ?";
			Employee emp=null;
			Connection conn = ConnectionFactory.getConnection();
			PreparedStatement pStatement= conn.prepareStatement(query);
			pStatement.setInt(1, empNo);
			ResultSet resultSet=pStatement.executeQuery();
			while(resultSet.next()) {
				emp=new Employee();
				emp.setEmpNo(resultSet.getInt("EmpNo"));
				emp.setEname(resultSet.getString("ename"));
				emp.setJob(resultSet.getString("job"));
				emp.setMgr(resultSet.getInt("mgr"));
				emp.setHiredate(resultSet.getDate("hireDate"));
				emp.setSal(resultSet.getInt("sal"));
				emp.setComm(resultSet.getInt("comm"));
				emp.setDeptNo(resultSet.getInt("deptNo"));
				
			}
			return emp;
		}
		
		public int update(int empNo) throws SQLException {
			String query="update Employee set sal=100 where empNo= ?";
			Connection conn = ConnectionFactory.getConnection();
			PreparedStatement pStatement= conn.prepareStatement(query);
			pStatement.setInt(1, empNo);
			int res=pStatement.executeUpdate();
			return res;
		}
		public int delete(int empNo) throws SQLException {
			String query="delete from Employee where empNo= ?";
			Connection conn = ConnectionFactory.getConnection();
			PreparedStatement pStatement= conn.prepareStatement(query);
			pStatement.setInt(1, empNo);
			int res=pStatement.executeUpdate();
			return res;
		}


		public static void main(String[] args) {
			try {
				System.out.println(new EmployeeDAO().insert(new Employee(1010, "Sachin", "Manager", 7369, new java.sql.Date(Calendar.getInstance().getTime().getTime()), 5000, 500, 20)));
				System.out.println(new EmployeeDAO().read(1000));
				System.out.println(new EmployeeDAO().update(1000));
				System.out.println(new EmployeeDAO().delete(1001));
			} 
			catch (SQLException e) {
				e.printStackTrace();
			}
		}

	}

